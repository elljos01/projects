﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
 // --------------------------go to the Home page at when app start.------------------------------------------
            MainFrame.Navigate(new HomePage());
        }

        private void HomeButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new HomePage());
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AddRecipePage());
        }

        private void ListRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ListRecipesPage());
        }

        private void FilterRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new FilterRecipesPage());
        }

        private void ClearDataButton_Click(object sender, RoutedEventArgs e)
        {
            AppData.RecipeRepository.ClearAllRecipes();
            MessageBox.Show("All recipe data has been cleared.");
        }
    } 
}