﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace POE
{
    /// <summary>
    /// Interaction logic for AddRecipePage.xaml
    /// </summary>
    public partial class AddRecipePage : Page
    {
        public ObservableCollection<Ingredient> Ingredients { get; set; }
        public ObservableCollection<string> Instructions { get; set; }
        public AddRecipePage()
        {
            InitializeComponent();
            Ingredients = new ObservableCollection<Ingredient>();
            Instructions = new ObservableCollection<string>();
            IngredientsItemsControl.ItemsSource = Ingredients;
            InstructionsItemsControl.ItemsSource = Instructions;
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            // Add a blank ingredient entry for the user to fill in.
            Ingredients.Add(new Ingredient("", "", 0, ""));
        }

        private void AddInstruction_Click(object sender, RoutedEventArgs e)
        {
            Instructions.Add("");
        }

        private void SaveRecipe_Click(object sender, RoutedEventArgs e)
        {
            string name = RecipeNameTextBox.Text;
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Please enter a recipe name.");
                return;
            }

            if (!int.TryParse(CaloriesTextBox.Text, out int calories))
            {
                MessageBox.Show("Please enter a valid number for calories.");
                return;
            }

            Recipe newRecipe = new Recipe(name, calories);
            foreach (var ing in Ingredients)
            {
                if (!string.IsNullOrWhiteSpace(ing.Name))
                {
                    newRecipe.AddIngredient(ing);
                }
            }
            foreach (var inst in Instructions)
            {
                if (!string.IsNullOrWhiteSpace(inst))
                {
                    newRecipe.AddInstruction(inst);
                }
            }

            AppData.RecipeRepository.AddRecipe(newRecipe);
            MessageBox.Show("Recipe saved successfully.");
        }
    }
}
