﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part1
{
    internal class Ingredient
    {
 //-------------------------------------------------------------------------------------     
        public string Name { get; set; }

        public double OriginalQuantity { get; set; }

        public double Quantity { get; set; }

        public string Unit { get; set; }
//--------------------------------------------------------------------------------------
       
        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            OriginalQuantity = quantity;
            Quantity = quantity;
            Unit = unit;
        }

/// ---------------Scales the ingredient quantity by a factor. (e.g., 0.5, 2, or 3)-------------------------
         
        public void Scale(double factor)
        {
            Quantity = OriginalQuantity * factor;
        }

 // ---------------------------Reset the quantity back to the original value---------------------------------
     
        public void Reset()
        {
            Quantity = OriginalQuantity;
        }
    }
}

