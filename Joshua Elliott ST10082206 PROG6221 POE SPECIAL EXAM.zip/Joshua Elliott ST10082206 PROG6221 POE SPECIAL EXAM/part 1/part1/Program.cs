﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part1
{
    /// <summary>
    /// The main entry point for the Recipe Application.
    /// </summary>
    class Program
    {
        
        
        
        static void Main(string[] args)
        {
  // -------------------------keep the current recipe in memory-------------------------------------------
            Recipe currentRecipe = null;

  // -------------------------loop of menu ----------------------------------------------------------------
            while (true)
            {
            
                Console.WriteLine("Recipe Application Menu:");
                Console.WriteLine("1. Enter a new recipe");
                Console.WriteLine("2. Display recipe");
                Console.WriteLine("3. Scale recipe");
                Console.WriteLine("4. Reset recipe quantities");
                Console.WriteLine("5. Clear recipe data");
                Console.WriteLine("6. Exit");
                Console.Write("Select an option (1-6): ");
                string userInput = Console.ReadLine();
                Console.WriteLine();

                
                switch (userInput)
                {
                    case "1":
                        
                        currentRecipe = CreateNewRecipe();
                        break;

                    case "2":
                        
                        if (currentRecipe != null)
                        {
                            currentRecipe.DisplayRecipe();
                        }
                        else
                        {
                            Console.WriteLine("No recipe data available. Please enter a recipe first.\n");
                        }
                        break;

                    case "3":
                       
                        if (currentRecipe != null)
                        {
                            ScaleRecipeOption(currentRecipe);
                        }
                        else
                        {
                            Console.WriteLine("No recipe data available. Please enter a recipe first.\n");
                        }
                        break;

                    case "4":
//--------------------- Reset the recipe quantities to their original values.--------------------------
                        if (currentRecipe != null)
                        {
                            currentRecipe.ResetRecipe();
                            Console.WriteLine("Recipe quantities have been reset to original values.\n");
                        }
                        else
                        {
                            Console.WriteLine("No recipe data available. Please enter a recipe first.\n");
                        }
                        break;

                    case "5":
                      
                        currentRecipe = null;
                        Console.WriteLine("Recipe data cleared. You can now enter a new recipe.\n");
                        break;

                    case "6":
                 
                        Console.WriteLine("Exiting application. Goodbye!");
                        return;

                    default:
                        Console.WriteLine("Invalid option. Please try again.\n");
                        break;
                }
            }
        }

      
        private static Recipe CreateNewRecipe()
        {
           
            Console.Write("Enter the number of ingredients: ");
            int numIngredients;
            while (!int.TryParse(Console.ReadLine(), out numIngredients) || numIngredients <= 0)
            {
                Console.Write("Invalid input. Please enter a positive integer for the number of ingredients: ");
            }

// -------------------------Create an array to store ingredients---------------------------------------------
            Ingredient[] ingredients = new Ingredient[numIngredients];

           
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"\nEnter details for ingredient {i + 1}:");

                Console.Write("Name: ");
                string name = Console.ReadLine();

                Console.Write("Quantity: ");
                double quantity;
                while (!double.TryParse(Console.ReadLine(), out quantity) || quantity <= 0)
                {
                    Console.Write("Invalid input. Please enter a positive number for quantity: ");
                }

                Console.Write("Unit of measurement: ");
                string unit = Console.ReadLine();

                ingredients[i] = new Ingredient(name, quantity, unit);
            }

            
            Console.Write("\nEnter the number of steps: ");
            int numSteps;
            while (!int.TryParse(Console.ReadLine(), out numSteps) || numSteps <= 0)
            {
                Console.Write("Invalid input. Please enter a positive integer for the number of steps: ");
            }

            
            string[] steps = new string[numSteps];

            
            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1} description: ");
                steps[i] = Console.ReadLine();
            }

            Recipe recipe = new Recipe(ingredients, steps);
            Console.WriteLine("\nRecipe successfully created!\n");
            return recipe;
        }

        
        private static void ScaleRecipeOption(Recipe recipe)
        {
            Console.Write("Enter scale factor (0.5 for half, 2 for double, 3 for triple): ");
            string factorInput = Console.ReadLine();
            double factor;
            if (!double.TryParse(factorInput, out factor) || (factor != 0.5 && factor != 2 && factor != 3))
            {
                Console.WriteLine("Invalid scale factor. Please enter 0.5, 2, or 3.\n");
                return;
            }

            recipe.ScaleRecipe(factor);
            Console.WriteLine($"Recipe scaled by a factor of {factor}.\n");
            recipe.DisplayRecipe();
        }
    }
}
