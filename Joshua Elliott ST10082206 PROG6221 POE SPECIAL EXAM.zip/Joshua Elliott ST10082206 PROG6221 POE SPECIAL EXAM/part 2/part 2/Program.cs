﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part1
{

    
        class Program
        {
            // Generic collection to store an unlimited number of recipes.
            private static List<Recipe> recipes = new List<Recipe>();

            /// <summary>
            /// Application entry point.
            /// Displays a menu and processes user input.
            /// </summary>
            static void Main(string[] args)
            {
                while (true)
                {
                    // Display the main menu.
                    Console.WriteLine("Recipe Application Menu:");
                    Console.WriteLine("1. Add a new recipe");
                    Console.WriteLine("2. List all recipes");
                    Console.WriteLine("3. Display a recipe");
                    Console.WriteLine("4. Scale a recipe");
                    Console.WriteLine("5. Reset recipe quantities");
                    Console.WriteLine("6. Clear all recipe data");
                    Console.WriteLine("7. Exit");
                    Console.Write("Select an option (1-7): ");
                    string choice = Console.ReadLine();
                    Console.WriteLine();

                    // Process the user's selection.
                    switch (choice)
                    {
                        case "1":
                            AddNewRecipe();
                            break;
                        case "2":
                            ListRecipes();
                            break;
                        case "3":
                            DisplaySelectedRecipe();
                            break;
                        case "4":
                            ScaleSelectedRecipe();
                            break;
                        case "5":
                            ResetSelectedRecipe();
                            break;
                        case "6":
                            ClearAllRecipes();
                            break;
                        case "7":
                            Console.WriteLine("Exiting application. Goodbye!");
                            return;
                        default:
                            Console.WriteLine("Invalid option. Please try again.\n");
                            break;
                    }
                }
            }

            /// <summary>
            /// Prompts the user for recipe details and adds a new recipe to the collection.
            /// </summary>
            private static void AddNewRecipe()
            {
                Console.Write("Enter the name of the recipe: ");
                string recipeName = Console.ReadLine();

                Console.Write("Enter the number of ingredients: ");
                int numIngredients;
                while (!int.TryParse(Console.ReadLine(), out numIngredients) || numIngredients <= 0)
                {
                    Console.Write("Invalid input. Please enter a positive integer for the number of ingredients: ");
                }

                List<Ingredient> ingredients = new List<Ingredient>();
                for (int i = 0; i < numIngredients; i++)
                {
                    Console.WriteLine($"\nEnter details for ingredient {i + 1}:");

                    Console.Write("Name: ");
                    string name = Console.ReadLine();

                    Console.Write("Quantity: ");
                    double quantity;
                    while (!double.TryParse(Console.ReadLine(), out quantity) || quantity <= 0)
                    {
                        Console.Write("Invalid input. Please enter a positive number for quantity: ");
                    }

                    Console.Write("Unit of measurement: ");
                    string unit = Console.ReadLine();

                    Console.Write("Calories: ");
                    int calories;
                    while (!int.TryParse(Console.ReadLine(), out calories) || calories < 0)
                    {
                        Console.Write("Invalid input. Please enter a non-negative integer for calories: ");
                    }

                    Console.Write("Food Group: ");
                    string foodGroup = Console.ReadLine();

                    Ingredient ingredient = new Ingredient(name, quantity, unit, calories, foodGroup);
                    ingredients.Add(ingredient);
                }

                Console.Write("\nEnter the number of steps: ");
                int numSteps;
                while (!int.TryParse(Console.ReadLine(), out numSteps) || numSteps <= 0)
                {
                    Console.Write("Invalid input. Please enter a positive integer for the number of steps: ");
                }

                List<string> steps = new List<string>();
                for (int i = 0; i < numSteps; i++)
                {
                    Console.Write($"Enter step {i + 1} description: ");
                    string step = Console.ReadLine();
                    steps.Add(step);
                }

                Recipe newRecipe = new Recipe(recipeName, ingredients, steps);
                // Subscribe to the calorie warning event.
                newRecipe.CalorieWarning += OnCalorieWarning;
                recipes.Add(newRecipe);
                Console.WriteLine("\nRecipe successfully created!\n");
            }

            /// <summary>
            /// Displays a list of all recipe names in alphabetical order.
            /// </summary>
            private static void ListRecipes()
            {
                if (recipes.Count == 0)
                {
                    Console.WriteLine("No recipes available.\n");
                    return;
                }

                Console.WriteLine("Recipes (alphabetical order):");
                // Order recipes by name.
                var orderedRecipes = recipes.OrderBy(r => r.Name).ToList();
                for (int i = 0; i < orderedRecipes.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {orderedRecipes[i].Name}");
                }
                Console.WriteLine();
            }

            /// <summary>
            /// Prompts the user to select a recipe from the list and displays its details.
            /// </summary>
            private static void DisplaySelectedRecipe()
            {
                if (recipes.Count == 0)
                {
                    Console.WriteLine("No recipes available to display.\n");
                    return;
                }

                ListRecipes();
                Console.Write("Enter the number of the recipe to display: ");
                int selection;
                if (!int.TryParse(Console.ReadLine(), out selection) || selection < 1 || selection > recipes.Count)
                {
                    Console.WriteLine("Invalid selection.\n");
                    return;
                }

                var orderedRecipes = recipes.OrderBy(r => r.Name).ToList();
                Recipe selectedRecipe = orderedRecipes[selection - 1];
                selectedRecipe.DisplayRecipe();
            }

            /// <summary>
            /// Prompts the user to select a recipe and a scaling factor, then scales the selected recipe.
            /// </summary>
            private static void ScaleSelectedRecipe()
            {
                if (recipes.Count == 0)
                {
                    Console.WriteLine("No recipes available to scale.\n");
                    return;
                }

                ListRecipes();
                Console.Write("Enter the number of the recipe to scale: ");
                int selection;
                if (!int.TryParse(Console.ReadLine(), out selection) || selection < 1 || selection > recipes.Count)
                {
                    Console.WriteLine("Invalid selection.\n");
                    return;
                }

                var orderedRecipes = recipes.OrderBy(r => r.Name).ToList();
                Recipe selectedRecipe = orderedRecipes[selection - 1];

                Console.Write("Enter scale factor (0.5 for half, 2 for double, 3 for triple): ");
                double factor;
                if (!double.TryParse(Console.ReadLine(), out factor) || (factor != 0.5 && factor != 2 && factor != 3))
                {
                    Console.WriteLine("Invalid scale factor. Please enter 0.5, 2, or 3.\n");
                    return;
                }

                selectedRecipe.ScaleRecipe(factor);
                Console.WriteLine($"Recipe scaled by a factor of {factor}.\n");
                selectedRecipe.DisplayRecipe();
            }

            /// <summary>
            /// Prompts the user to select a recipe and resets its ingredient quantities and calories.
            /// </summary>
            private static void ResetSelectedRecipe()
            {
                if (recipes.Count == 0)
                {
                    Console.WriteLine("No recipes available to reset.\n");
                    return;
                }

                ListRecipes();
                Console.Write("Enter the number of the recipe to reset: ");
                int selection;
                if (!int.TryParse(Console.ReadLine(), out selection) || selection < 1 || selection > recipes.Count)
                {
                    Console.WriteLine("Invalid selection.\n");
                    return;
                }

                var orderedRecipes = recipes.OrderBy(r => r.Name).ToList();
                Recipe selectedRecipe = orderedRecipes[selection - 1];
                selectedRecipe.ResetRecipe();
                Console.WriteLine("Recipe quantities and calories have been reset to their original values.\n");
                selectedRecipe.DisplayRecipe();
            }

            /// <summary>
            /// Clears all recipe data from the application.
            /// </summary>
            private static void ClearAllRecipes()
            {
                recipes.Clear();
                Console.WriteLine("All recipe data has been cleared.\n");
            }

            /// <summary>
            /// Event handler for calorie warnings.
            /// Notifies the user when the total calories exceed 300.
            /// </summary>
            /// <param name="recipe">The recipe that exceeded the calorie limit.</param>
            /// <param name="totalCalories">The total calories in the recipe.</param>
            private static void OnCalorieWarning(Recipe recipe, int totalCalories)
            {
                Console.WriteLine($"Warning: The total calories for '{recipe.Name}' exceed 300 calories ({totalCalories} calories)!\n");
            }
        }
    }

