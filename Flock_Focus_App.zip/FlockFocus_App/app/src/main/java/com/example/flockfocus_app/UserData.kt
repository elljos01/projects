package com.example.flockfocus_app

data class UserData(
    val name: String,
    val surname: String,
    val username: String,
    val email: String,
    val password: String
)