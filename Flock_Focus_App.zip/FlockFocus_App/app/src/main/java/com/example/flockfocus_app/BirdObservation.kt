package com.example.flockfocus_app

data class BirdObservation(
    val species : String,
    val location : String,
    val date : String
)
