package com.example.flockfocus_app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase


class LoginFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private val RC_SIGN_IN = 123

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_login, container, false)

        //Instance of Auth
        auth = FirebaseAuth.getInstance()

        val currentUser = auth.currentUser
        if (currentUser != null) {
            // add an activity or switch to main activity as still signed in
            navigateToMain()
        } else {
            // show the sign in option
            showSignInOption()
        }

        // Find views
        val loginButton = view.findViewById<Button>(R.id.btnLogin)
        val createAccountLink = view.findViewById<TextView>(R.id.createNewAccount)

        //Button Click listeners
        loginButton.setOnClickListener {
            // Get a reference to the UserViewModel
            //Change ViewModel to Registration
            //                       val viewModel = ViewModelProvider(requireActivity()).get(UserViewModel::class.java)

            // Retrieve email and password entered by the user
            val email = view.findViewById<EditText>(R.id.inputEmail).text.toString()
            val password = view.findViewById<EditText>(R.id.inputPassword).text.toString()
            signInWithEmail(email, password)
        }
        // Search for the user in the ViewModel's userList
          createAccountLink.setOnClickListener {
              findNavController().navigate(R.id.action_loginFragment_to_registerFragment)
          }
        return view
    }

    // Clicking on "Create new Account?" link should navigate to the RegisterFragment
    private fun showSignInOption(){
        //Handle the UI for sign-in options

    }

    private fun signInWithEmail(email: String, password:String){
        auth.signInWithEmailAndPassword(email,password)
            .addOnCompleteListener {task ->
                if(task.isSuccessful){
                    val user = auth.currentUser

                    //Check the current userdetails
                    saveAdditionalUserDetails(user,"Get A Usernamer")
                    navigateToMain()

                    // create to menu navigateToMain() to the Hotspot Menu
                }else{
                    //if registration fails
                    Toast.makeText(
                        requireContext(), "Authentication failed",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }
    private fun saveAdditionalUserDetails(user:FirebaseUser?, username:String){
        //Save additional details to the database
        if(user != null){
            val userId = user.uid?:""
            val userEmail = user.email?:""

            //Save details to Firebase Realtime Database
            val database = FirebaseDatabase.getInstance()
            val userRef = database.getReference("users")

            val userMap = HashMap<String, Any>()
            userMap["userId"] = userId
            userMap["userEmail"]= userEmail
            userMap["username"] = username

            userRef.child(userId).setValue(userMap)
        }
    }

    private fun navigateToMain(){
        findNavController().navigate(R.id.action_login_to_hotspots)

        // Implement to Navigate to activity without Signing in
    }
}
