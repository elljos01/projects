package com.example.flockfocus_app

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize your navigation controller
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.mainContainer) as NavHostFragment
        val navController = navHostFragment.navController

        // Initialize your bottom navigation view
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigation)

        // Set up the bottom navigation with the NavController
        bottomNavigationView.setupWithNavController(navController)

        // Initially hide the bottom navigation
        hideBottomNavigationBar()

        navController.addOnDestinationChangedListener { _, destination, _ ->
            // Check if the current destination is HotspotsFragment
            if (destination.id == R.id.hotspotsFragment) {
                // Show the bottom navigation bar
                showBottomNavigationBar()
            } else {
                // Hide the bottom navigation bar for other destinations
              //  hideBottomNavigationBar()
            }
        }
    }

    private fun hideBottomNavigationBar() {
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigationView.visibility = View.GONE
    }

    private fun showBottomNavigationBar() {
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigationView.visibility = View.VISIBLE
    }
}

