package com.example.flockfocus_app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.flockfocus_app.databinding.FragmentDirectionsBottomSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class DirectionsBottomSheetFragment : BottomSheetDialogFragment() {

    private var _binding: FragmentDirectionsBottomSheetBinding? = null
    private val binding get() = _binding!!

    companion object {
        private const val DISTANCE_KEY = "distance"

        fun newInstance(distance: String): DirectionsBottomSheetFragment {
            val fragment = DirectionsBottomSheetFragment()
            val args = Bundle()
            args.putString(DISTANCE_KEY, distance)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDirectionsBottomSheetBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val distance = arguments?.getString(DISTANCE_KEY) ?: ""

        binding.distanceTextView.text = distance
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
