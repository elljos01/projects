package com.example.flockfocus_app

import androidx.lifecycle.ViewModel


class UserViewModel : ViewModel() {
    // Define a property to store the list of registered users
    val userList = ArrayList<UserData>()
}