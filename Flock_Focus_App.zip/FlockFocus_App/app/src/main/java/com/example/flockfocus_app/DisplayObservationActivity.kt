package com.example.flockfocus_app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.flockfocus_app.databinding.ActivityDisplayObservationBinding

class DisplayObservationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDisplayObservationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDisplayObservationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Create a new ObservationFragment


        // Replace the fragmentContainer with the ObservationFragment
    }
}



