package com.example.flockfocus_app

import com.google.maps.DirectionsApi
import com.google.maps.GeoApiContext
import com.google.maps.model.DirectionsResult
import com.google.maps.model.TravelMode

class DirectionsService(apiKey: String) {
    private val context = GeoApiContext.Builder()
        .apiKey(apiKey)
        .build()

    fun getDirections(startLocation: String, endLocation: String): DirectionsResult? {
        return try {
            val directionsResult = DirectionsApi.newRequest(context)
                .mode(TravelMode.DRIVING)
                .origin(startLocation)
                .destination(endLocation)
                .await()

            directionsResult
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}