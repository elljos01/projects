package com.example.flockfocus_app

import retrofit2.Call
import retrofit2.http.GET

interface EBirdApiService {
    @GET("your/api/endpoint")
    suspend fun getBirdObservations(): Call<List<BirdObservation>>
}