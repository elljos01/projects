package com.example.flockfocus_app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class RegisterFragment : Fragment() {
    
    private lateinit var auth: FirebaseAuth
    
override fun onCreateView(
    inflater: LayoutInflater, container: ViewGroup?,
    savedInstanceState: Bundle?
): View? {
    // Inflate the layout for this fragment
    return inflater.inflate(R.layout.fragment_register, container, false)
}

override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
    auth = FirebaseAuth.getInstance()

   // val viewModel = ViewModelProvider(requireActivity())[UserViewModel::class.java]
    val registrationButton = view.findViewById<Button>(R.id.btnRegister)

    registrationButton.setOnClickListener {
        val name = view.findViewById<EditText>(R.id.name).text.toString()
        val surname = view.findViewById<EditText>(R.id.surname).text.toString()
        val username = view.findViewById<EditText>(R.id.username).text.toString()
        val email = view.findViewById<EditText>(R.id.inputEmail).text.toString()
        val password = view.findViewById<EditText>(R.id.inputPassword).text.toString()

        signUpWithEmail(name, surname, username, email, password)
    }
}

    private fun signUpWithEmail(name: String, surname: String, username: String, email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        saveAdditionalUserDetails(user.uid, name, surname, username, email)
                        clearInputFields()
                        findNavController().navigate(R.id.action_register_to_login)
                    }
                } else {
                    Toast.makeText(
                        requireContext(), "Registration failed. Please try again.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }

    private fun saveAdditionalUserDetails(userId: String, name: String, surname: String, username: String, email: String) {
        val database = FirebaseDatabase.getInstance()
        val userRef = database.getReference("users").child(userId)

        val userMap = HashMap<String, Any>()
        userMap["name"] = name
        userMap["surname"] = surname
        userMap["username"] = username
        userMap["email"] = email

        userRef.setValue(userMap)
    }

    private fun clearInputFields() {
    // Clear input fields here
    view?.findViewById<EditText>(R.id.name)?.text?.clear()
    view?.findViewById<EditText>(R.id.surname)?.text?.clear()
    view?.findViewById<EditText>(R.id.username)?.text?.clear()
    view?.findViewById<EditText>(R.id.inputEmail)?.text?.clear()
    view?.findViewById<EditText>(R.id.inputPassword)?.text?.clear()
}

// Rest of your code...
}
