package com.example.flockfocus_app

import Sighting
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ExploreBirdsFragment : Fragment() {
    private val sightings = ArrayList<Sighting>()
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    companion object {
        fun newInstance(selectedSighting: Sighting): ExploreBirdsFragment {
            val fragment = ExploreBirdsFragment()
            val args = Bundle()
            args.putParcelable("selectedSighting", selectedSighting)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_explore_birds, container, false)

        auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser
        database = FirebaseDatabase.getInstance().getReference("users").child((currentUser?.uid ?: ""))

        // Check For changes in user sightings
        observeUserSightings()

        val buttonStoreSighting = view.findViewById<Button>(R.id.buttonStoreObservation)

        buttonStoreSighting.setOnClickListener {
            val title = view.findViewById<EditText>(R.id.editTextTitle).text.toString()
            val date = view.findViewById<EditText>(R.id.editTextDate).text.toString()
            val description = view.findViewById<EditText>(R.id.editTextDescription).text.toString()


            val sighting = Sighting(title, date, description)

            // Save Sighting to Firebase Realtime Database
            saveSightingToDatabase(sighting)

            // Clear EditText fields if needed
            view.findViewById<EditText>(R.id.editTextTitle).text.clear()
            view.findViewById<EditText>(R.id.editTextDate).text.clear()
            view.findViewById<EditText>(R.id.editTextDescription).text.clear()
        }

        val buttonViewSighting = view.findViewById<Button>(R.id.buttonViewObservation)
        buttonViewSighting.setOnClickListener {
            val intent = Intent(requireContext(), DisplayObservationActivity::class.java)

            // Pass your ArrayList or other data to the activity
            intent.putExtra("sightings", sightings)

            startActivity(intent)
        }

        return view
    }

    private fun observeUserSightings() {
        // Set ValueEventListener to observe changes in user sightings
        val sightingsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                sightings.clear()
                for (sightingSnapshot in snapshot.children) {
                    val sighting = sightingSnapshot.getValue(Sighting::class.java)
                    if (sighting != null) {
                        sightings.add(sighting)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle the errors
            }
        }
        // Add the ValueEventListener to the database reference
        database.child("sightings").addValueEventListener(sightingsListener)
    }

    private fun saveSightingToDatabase(sighting: Sighting) {
        // Save the sighting to the user's sightings in Firebase Realtime Database
        val sightingRef = database.child("sightings").push()
        sightingRef.setValue(sighting)
    }
}
