import android.os.Parcel
import android.os.Parcelable

data class Sighting(
    val title: String,
    val date: String,
    val description: String,
    val speciesId: String = "",
    val birdingHotspotName: String = "",
    val birdingHotspotLatitude: String = "",
    val birdingHotspotLongitude: String = "",
    val speciesName: String = "",
    val speciesDescription: String = "",
    val speciesGender: String = "",
    val speciesTypeSighting: String = "",
    val speciesCaptureDate: String = ""
) : Parcelable {
    constructor() : this("", "", "")

    // Parcelable implementation
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: ""
    )

    override fun describeContents(): Int = 0

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(title)
        parcel.writeString(date)
        parcel.writeString(description)
        parcel.writeString(speciesId)
        parcel.writeString(birdingHotspotName)
        parcel.writeString(birdingHotspotLatitude)
        parcel.writeString(birdingHotspotLongitude)
        parcel.writeString(speciesName)
        parcel.writeString(speciesDescription)
        parcel.writeString(speciesGender)
        parcel.writeString(speciesTypeSighting)
        parcel.writeString(speciesCaptureDate)
    }

    companion object CREATOR : Parcelable.Creator<Sighting> {
        override fun createFromParcel(parcel: Parcel): Sighting {
            return Sighting(parcel)
        }

        override fun newArray(size: Int): Array<Sighting?> {
            return arrayOfNulls(size)
        }
    }
}