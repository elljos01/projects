package com.example.flockfocus_app

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class SettingsFragment : Fragment() {
    private lateinit var sharedPrefs: SharedPreferences
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private lateinit var kmSwitch: Switch
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private lateinit var milesSwitch: Switch
    private lateinit var distanceSeekBar: SeekBar
    private lateinit var distanceText: TextView

    //FirebaseAuth and Firebase Realtime Database Implementation
    private lateinit var auth:FirebaseAuth
    private lateinit var database: DatabaseReference
    private lateinit var user: FirebaseUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPrefs = requireActivity().getSharedPreferences("MySettings", Context.MODE_PRIVATE)
        //Instantiate on Create Firebase
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        database = FirebaseDatabase.getInstance().getReference("users").child(user.uid)
    }

    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)



        kmSwitch = view.findViewById(R.id.KmswitchUnit)
        milesSwitch = view.findViewById(R.id.MilesswitchUnit)
        distanceSeekBar = view.findViewById(R.id.seekBarDistance)
        distanceText = view.findViewById(R.id.textViewDistance)

        // Load and set the initial state of switches and seek bar from SharedPreferences
        val isMetric = sharedPrefs.getBoolean("isMetric", true)
        val maxDistance = sharedPrefs.getInt("maxDistance", 0)

        kmSwitch.isChecked = isMetric
        milesSwitch.isChecked = !isMetric
        distanceSeekBar.progress = maxDistance
        distanceText.text = "Distance: $maxDistance km"

        updateDistanceText(maxDistance, isMetric)

        // Set listeners for switches and seek bar
        kmSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                milesSwitch.isChecked = !isChecked
                saveUnitPreference(true)
                updateDistanceText(distanceSeekBar.progress, true)

                saveSettingsToFirebase(true,distanceSeekBar.progress)
                //saave to firebase
            }
        }

        milesSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                kmSwitch.isChecked = !isChecked
                saveUnitPreference(false)
                updateDistanceText(distanceSeekBar.progress, false)

                saveSettingsToFirebase(false, distanceSeekBar.progress)
                //save to firebase
            }
        }

        distanceSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateDistanceText(progress, kmSwitch.isChecked)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Not needed in this example
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                saveDistancePreference(seekBar?.progress ?: 0)
                //Saves the Current Position and Metric Used
                saveSettingsToFirebase(kmSwitch.isChecked,seekBar?.progress ?: 0)
            }
        })

        // Update distance text based on user's unit preference
        updateDistanceTextInBottomSheet()

        return view
    }

    private fun saveUnitPreference(isMetric: Boolean) {
        sharedPrefs.edit().putBoolean("isMetric", isMetric).apply()
    }

    private fun saveDistancePreference(maxDistance: Int) {
        sharedPrefs.edit().putInt("maxDistance", maxDistance).apply()
        Log.d("SettingsFragment", "Saved max distance preference: $maxDistance")

    }

    private fun updateDistanceText(distance: Int, isMetric: Boolean) {
        val unit = if (isMetric) "km" else "miles"
        distanceText.text = "Distance: $distance $unit"
    }

    private fun updateDistanceTextInBottomSheet() {
        val isMetric = sharedPrefs.getBoolean("isMetric", true)
        val maxDistance = sharedPrefs.getInt("maxDistance", 0)

        // Determine the unit based on the user's selection
        val unit = if (isMetric) "km" else "miles"
        val distanceTextInBottomSheet = "Distance: $maxDistance $unit"

        // Create a bundle to pass the distance to the bottom sheet fragment
        val args = Bundle()
        args.putString("formattedDistance", distanceTextInBottomSheet)
        args.putInt("maxDistance", maxDistance)

        // Find the bottom sheet fragment
        val bottomSheetFragment =
            parentFragmentManager.findFragmentByTag("bottomSheet") as DirectionsBottomSheetFragment?

        // Set the arguments to update the distance text in the bottom sheet
        bottomSheetFragment?.arguments = args
    }
    private fun saveSettingsToFirebase(isMetric:Boolean, maxDistance: Int){
        val settingsMap = HashMap<String, Any>()
        settingsMap["isMetric"] = isMetric
        settingsMap["maxDistance"] = maxDistance

        database.child("settings").setValue(settingsMap)
    }
}