package com.example.flockfocus_app


import Sighting
import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.maps.android.PolyUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException


class HotspotsFragment : Fragment(), OnMapReadyCallback {


    private var selectedSighting: Sighting? = null

    private lateinit var mMap: GoogleMap
    private val LOCATION_PERMISSION_REQUEST = 1
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var sharedPrefs: SharedPreferences
    private lateinit var mAuth: FirebaseAuth
    private lateinit var mDatabase: DatabaseReference

    private val apiKey = "nv3ddmhnp7t4"
    private val directionsApiKey = "AIzaSyB1wbGShdaTI-KxNSudKY_3Ep0LIPMql-k"
    //private lateinit var Directionbtn: Button
    //private lateinit var addObservation: Button
    private var destinationLocation: LatLng? = null
    private var currentPolyline: Polyline? = null

    @SuppressLint("MissingPermission")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_hotspots, container, false)

        val mapFragment =
            childFragmentManager.findFragmentById(R.id.google_map) as SupportMapFragment

        mapFragment.getMapAsync(this)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())
        sharedPrefs = requireActivity().getSharedPreferences("MySettings", Context.MODE_PRIVATE)
        mAuth = FirebaseAuth.getInstance()
        mDatabase = FirebaseDatabase.getInstance().reference

        val addObservationButton: Button = view.findViewById(R.id.addObservation)
        addObservationButton.isEnabled = true // Disable the button initially

        addObservationButton.setOnClickListener {
            if (destinationLocation != null) {
                Log.d("Check Button", "Add Observation button clicked")
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { location ->
                        location?.let {
                            val currentLocation = LatLng(it.latitude, it.longitude)
                            hotspotDirections(destinationLocation!!)
                            val formattedDistance = calculateDistance(it, currentLocation)
                            Log.d("Check Button", "Distance: $formattedDistance")

                            // Save sighting requirements to Firebase
                            saveSightingRequirements()

                            val bottomSheetFragment =
                                DirectionsBottomSheetFragment.newInstance(formattedDistance)
                            bottomSheetFragment.show(parentFragmentManager, bottomSheetFragment.tag)

                            // Use navigate function to navigate to ExploreBirdsFragment
                            val action = HotspotsFragmentDirections.actionHotspotsFragmentToExploreBirdsFragment()
                            findNavController().navigate(action)




                        } ?: run {
                            Log.d("Check Button", "Unable to get current location")
                        }
                    }
            } else {
                Log.d("Check Button", "Add Observation button clicked, but destinationLocation is null")
            }
        }




        return view
    }

    @SuppressLint("PotentialBehaviorOverride")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mMap.isMyLocationEnabled = true
            deviceLocation()
            locationAndHotspots()

            // Inside the onMapReady function
            mMap.setOnMarkerClickListener { marker ->
                if (marker.title != "Your Location") {
                    if (ContextCompat.checkSelfPermission(
                            requireContext(),
                            Manifest.permission.ACCESS_FINE_LOCATION
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        val locationResult = fusedLocationClient.lastLocation
                        locationResult.addOnSuccessListener { location: Location? ->
                            location?.let {
                                val currentLocation = it
                                destinationLocation = marker.position
                                calculateDistance(currentLocation, destinationLocation!!)

                                // Add polyline from current location to the selected marker
                                val polylineOptions = PolylineOptions()
                                    .add(LatLng(currentLocation.latitude, currentLocation.longitude))
                                    .add(destinationLocation!!)
                                    .width(5f)
                                    .color(Color.RED)
                                mMap.addPolyline(polylineOptions)
                            }
                        }
                    } else {
                        ActivityCompat.requestPermissions(
                            requireActivity(),
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                            LOCATION_PERMISSION_REQUEST
                        )
                    }
                }
                false
            }



        } else {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST
            )
        }
    }

    private fun saveSightingRequirements() {
        val userId = mAuth.currentUser?.uid
        val sightingRequirementsRef = mDatabase.child("sightingRequirements").child(userId!!)
        val sightingRequirements = HashMap<String, Any>()
        // Modify this part based on your sighting requirements data structure
        sightingRequirements["requirement1"] = "value1"
        sightingRequirements["requirement2"] = "value2"
        sightingRequirementsRef.setValue(sightingRequirements)
    }

    private fun deviceLocation() {
        try {
            val locationResult = fusedLocationClient.lastLocation
            locationResult.addOnSuccessListener { location: Location? ->
                location?.let {
                    val currentLocation = LatLng(it.latitude, it.longitude)
                    mMap.addMarker(
                        MarkerOptions().position(currentLocation).title("Current Location")
                    )
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 15.0f))
                }
            }
        } catch (e: SecurityException) {
            // Handle location permission error
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                onMapReady(mMap)
            } else {
                // Handle the permission when denied
            }
        }
    }

    private fun locationAndHotspots() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        val userLocation = LatLng(location.latitude, location.longitude)
                        mMap.addMarker(
                            MarkerOptions().position(userLocation).title("Your Location")
                        )
                        hotspotsEBird(userLocation)
                    }
                }
        }
    }

    private fun hotspotsEBird(userLocation: LatLng) {
        val maxDistance = 50
        Log.d("HotspotsFragment", "Max Distance from SharedPreferences: $maxDistance")

        val url =
            "https://api.ebird.org/v2/ref/hotspot/geo?lat=${userLocation.latitude}&lng=${userLocation.longitude}&dist=$maxDistance"
        Log.d("HotspotsFragment", "API Request URL: $url")
        val request = Request.Builder()
            .url(url)
            .header("X-Auth-Token", apiKey)
            .build()

        val client = OkHttpClient()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    responseBody?.let { Log.d("API Response", it) }

                    if (!responseBody.isNullOrEmpty()) {
                        hotspotsMarkers(responseBody)
                    } else {
                        Log.w("Response", "No hotspots found within the specified range.")
                    }
                } else {
                    Log.e("Response", "Failed to fetch eBird data: ${response.code}")
                    response.body?.string()?.let { Log.e("Response", it) }
                }
            } catch (e: IOException) {
                Log.e("Request", "Failed to make eBird API request: ${e.message}")
            }
        }
    }

    @SuppressLint("PotentialBehaviorOverride")
    private fun hotspotsMarkers(responseBody: String) {
        if (responseBody.isEmpty()) {
            Log.w("Response", "Response body is empty.")
            return
        }

        val lines = responseBody.split("\n")

        CoroutineScope(Dispatchers.Main).launch {
            for (line in lines) {
                val parts = line.split(",")

                if (parts.size >= 7) {
                    val name = parts[6]
                    val latitude = parts[4].toDoubleOrNull()
                    val longitude = parts[5].toDoubleOrNull()

                    if (latitude != null && longitude != null) {
                        val hotspotLocation = LatLng(latitude, longitude)
                        val markerOptions = MarkerOptions()
                            .position(hotspotLocation)
                            .title(name)
                            .snippet("Lat: $latitude, Lng: $longitude")
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))

                        val sightings = Sighting(
                            title = name,
                            date = "Observation Date", // Replace with the actual date
                            description = "Observation Description", // Replace with the actual description
                            birdingHotspotName = name,
                            birdingHotspotLatitude = latitude.toString(),
                            birdingHotspotLongitude = longitude.toString(),
                            speciesId = "Species ID",
                            speciesName = "Species Name",
                            speciesDescription = "Species Description",
                            speciesGender = "Species Gender",
                            speciesTypeSighting = "Species Type of Sighting",
                            speciesCaptureDate = "Species Capture Date"
                        )

                        val marker = mMap.addMarker(markerOptions)
                        marker?.tag = sightings

                        // Set marker click listener
                        mMap.setOnMarkerClickListener { clickedMarker ->
                            // Store the selected sighting when the marker is clicked
                            selectedSighting = clickedMarker.tag as? Sighting
                            false // Continue with the default behavior (e.g., show info window)
                        }
                    }
                }
            }
        }
    }



    data class DirectionsData(
        var polyline: String = ""
    )

    private fun directionsResponse(responseBody: String): DirectionsData {
        val data = DirectionsData()

        try {
            val jsonObject = JSONObject(responseBody)
            val routes = jsonObject.getJSONArray("routes")
            if (routes.length() > 0) {
                val route = routes.getJSONObject(0)
                val overviewPolyline = route.getJSONObject("overview_polyline")
                data.polyline = overviewPolyline.getString("points")
            }
        } catch (e: Exception) {
            Log.e("Directions", "Failed to parse directions response: ${e.message}")
        }

        return data
    }

    private fun routeDisplay(directionsData: DirectionsData) {
        val polylineOptions = PolylineOptions()
            .addAll(PolyUtil.decode(directionsData.polyline))
            .width(10f)
            .color(Color.BLUE)

        requireActivity().runOnUiThread {
            if (currentPolyline != null) {
                currentPolyline?.remove()
            }
            currentPolyline = mMap.addPolyline(polylineOptions)
        }
    }

    private fun calculateDistance(currentLocation: Location, destination: LatLng): String {
        val results = FloatArray(1)
        Location.distanceBetween(
            currentLocation.latitude,
            currentLocation.longitude,
            destination.latitude,
            destination.longitude,
            results
        )

        val distance = results[0]
        val isMetric = sharedPrefs.getBoolean("isMetric", true) // Read the user's unit preference from SharedPreferences

        val unit = if (isMetric) "km" else "miles"

        return if (isMetric) {
            String.format("%.2f $unit", distance / 1000.0) // Convert meters to kilometers
        } else {
            String.format("%.2f $unit", distance / 1609.34) // Convert meters to miles
        }
    }

    private fun hotspotDirections(destination: LatLng) {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        val origin = "${location.latitude},${location.longitude}"
                        val destinationStr = "${destination.latitude},${destination.longitude}"
                        val apiKey = directionsApiKey

                        val url =
                            "https://maps.googleapis.com/maps/api/directions/json?origin=$origin&destination=$destinationStr&key=$apiKey"

                        val request = Request.Builder()
                            .url(url)
                            .build()

                        val client = OkHttpClient()

                        CoroutineScope(Dispatchers.IO).launch {
                            try {
                                val response = client.newCall(request).execute()
                                if (response.isSuccessful) {
                                    val responseBody = response.body?.string()
                                    if (!responseBody.isNullOrEmpty()) {
                                        Log.d(
                                            "Directions Response",
                                            responseBody
                                        )
                                        val directionsData = directionsResponse(responseBody)
                                        routeDisplay(directionsData)
                                    } else {
                                        Log.w(
                                            "Directions Response",
                                            "No data received from Google Directions API."
                                        )
                                    }
                                } else {
                                    Log.e(
                                        "Directions Response",
                                        "Failed to fetch directions: ${response.code}"
                                    )
                                    response.body?.string()
                                        ?.let { Log.e("Directions Response", it) }
                                }
                            } catch (e: IOException) {
                                Log.e(
                                    "Directions Request",
                                    "Failed to make directions API request: ${e.message}"
                                )
                            }
                        }
                    }
                }
        }
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        val addObservationButton: Button = view.findViewById(R.id.addObservation)

        // Set button click listener
        addObservationButton.setOnClickListener {
            // Check if a sighting is selected
            if (selectedSighting != null) {
                // Navigate to Explore Birds Fragment and pass the selected sighting details
                val exploreBirdsFragment = ExploreBirdsFragment.newInstance(selectedSighting!!)

                // Use your navigation logic here (e.g., FragmentTransaction or navigation component)
                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainer, exploreBirdsFragment) // Replace with your container ID
                    .addToBackStack(null) // Optional: Add to back stack
                    .commit()
            } else {
                // Handle the case when no sighting is selected
                // You may show a message or perform other actions
            }
        }

    }
}
