data class Sighting(
    val title: String,
    val date: String,
    val description: String,
    val speciesId: String = "",
    val birdingHotspotName: String = "",
    val birdingHotspotLatitude: String = "",
    val birdingHotspotLongitude: String = "",
    val speciesName: String = "",
    val speciesDescription: String = "",
    val speciesGender: String = "",
    val speciesTypeSighting: String = "",
    val speciesCaptureDate: String = ""
)
